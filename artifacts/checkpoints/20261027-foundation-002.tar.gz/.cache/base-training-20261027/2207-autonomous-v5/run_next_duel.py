from pathlib import Path
from datetime import datetime,timezone
from dataclasses import asdict
import json,traceback,hashlib,torch,os,sys
from ygo_kito.period_runtime import PeriodBuildAssets
from ygo_kito.course_models import CourseModels
from ygo_kito.course_game_adapter import CourseBotRuntime,CourseGameAdapter
from ygo_kito.bot_deployment import BotSourceRegistry
from ygo_kito.build_contracts import DeckParts,digest
from ygo_kito.deck_intake import parse_ydk
from ygo_kito.match_runner import MatchState,MatchParticipant,MatchRules
from ygo_kito.data_isolation import DataIndex
R=Path('.cache/base-training-20261027/2207-autonomous-v5');ORDINAL=int(sys.argv[1]);D=R/('duel-'+str(ORDINAL).zfill(3));D.mkdir(exist_ok=True)
def save(name,v):
 p=D/name;t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n');t.replace(p)
def read(v):return json.loads(Path(v['path']).read_text())
def state(s,**kw):
 v=dict(stage=s,time_utc=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),**kw);save('status.json',v);print(json.dumps(v,ensure_ascii=False),flush=True)
models=None;adapter=None
try:
 torch.set_num_threads(2);state('restoring_base_foundation_for_actual_training')
 if (D/'in-flight.json').exists() or (D/'result.json').exists():raise RuntimeError('existing attempt must be inspected, never automatically replayed')
 old=json.loads((R/'runtime-host.json').read_text())
 assets=PeriodBuildAssets(Path('.cache').resolve(),'2022-07',read(old['active_environment']),Path.cwd(),adapter_revision=5,evidence_source='user_supplied')
 binding=json.loads((R/'binding.json').read_text());actual={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('src/ygo_kito').glob('*.py'))}
 if binding['source_files']!=actual:raise RuntimeError('source changed since base checkpoint; explicit migration required')
 models=CourseModels.from_state(torch.load(Path(json.loads((R/'latest-pointer.json').read_text())['path']),weights_only=False),assets=assets,expected_binding=binding)
 if models.duel.updates+1 != ORDINAL:raise RuntimeError('next duel ordinal differs from saved optimizer/sampler cursor')
 save('restored-state.json',{'fingerprint':models.fingerprint(),'versions':models.versions(),'base_build_updates':models.builder.updates,'duel_updates':models.duel.updates,'coordinator_updates':models.coordinator.updates,'adapter_count':len(models.sessions)})
 b=next(b for b in old['bots'] if b['stage']=='bots-bo1' and b['purpose']=='train' and 'CyberDragon' in b['executor_id'])
 registry=BotSourceRegistry(read(b['lock']),Path(b['installed_root']).resolve())
 runtime=CourseBotRuntime(registry=registry,workspace=Path.cwd(),source_id=b['source_id'],executor_id=b['executor_id'],audit=b['audit'],qualification=b['qualification'],qualification_profile=b['qualification_profile'],mono=b['mono'],opponent_id=b['bot_id'],source=b['source'],session_seconds=b['session_seconds'],variant_root=Path(b['variant_root']).resolve() if 'variant_root' in b else None)
 dp=Path(b['deck']['path']);botdeck=DeckParts.from_dict(parse_ydk(dp.read_text()) if dp.suffix=='.ydk' else json.loads(dp.read_text()))
 deck=DeckParts.from_dict(json.loads((R/'generated-deck.json').read_text()));rules=MatchRules(assets.rows,assets.limits,models.available_ids)
 match=MatchState('pearl-base-duel-'+str(ORDINAL).zfill(3),(MatchParticipant('actor',deck),MatchParticipant('opponent',botdeck)),rules,{'kind':'separate-base-foundation-learning','purpose':'train','formal_course_credit':False,'reference_inputs':[],'source_binding_sha256':digest(binding)},'actor' if ORDINAL%2 else 'opponent',adapter_revision=assets.adapter_revision)
 state('constructing_actual_training_adapter',opponent=b['executor_id'],learner_deck_sha256=digest(deck.to_dict()),base_build_updates=models.builder.updates)
 adapter=CourseGameAdapter(assets=assets,match_state=match,actor_participant_id='actor',trainer=models.duel,adapter_session=None,bot_runtime=runtime,data_index=DataIndex(R/'index'),experiment_id='pearl-base-2207-v1',purpose='train',policy_rng=models.policy_rng)
 spec=match.issue_game_spec();save('in-flight.json',{'match_id':spec.match_id,'status':'execution_started_no_automatic_replay'});state('actual_engine_sampling_and_base_ppo')
 result=adapter(spec);match.record_game(spec,result)
 save('result.json',{'game':asdict(result),'match':match.to_dict(),'receipt':adapter.last_receipt,'diagnostics':adapter.last_partial_diagnostics,'scope':'base-foundation-training-not-formal-course-count'})
 if adapter.last_receipt.get('model_update_completed'):
  torch.save(models.save_state(),D/'after.weights');checkpoint=R/('latest-after-duel-'+str(ORDINAL).zfill(3)+'.weights');torch.save(models.save_state(),checkpoint)
  pointer={'path':str(checkpoint),'sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'duel_updates':models.duel.updates};temp=R/'latest-pointer.json.tmp';temp.write_text(json.dumps(pointer,indent=2)+'\n');temp.replace(R/'latest-pointer.json')
 state('saved_actual_training_result',duel_updates=models.duel.updates,model_update_completed=adapter.last_receipt.get('model_update_completed'),sample_completed=adapter.last_receipt.get('sample_completed'))
 (D/'in-flight.json').rename(D/'closed-flight.json')
except Exception as e:
 if models is not None:
  try:torch.save(models.save_state(),D/'last-boundary.weights')
  except Exception as se:print('BOUNDARY_SAVE_ERROR',repr(se),flush=True)
 if adapter is not None:save('failure-receipt.json',{'receipt':adapter.last_receipt,'diagnostics':adapter.last_partial_diagnostics})
 state('actual_training_error',error=repr(e));traceback.print_exc();raise
