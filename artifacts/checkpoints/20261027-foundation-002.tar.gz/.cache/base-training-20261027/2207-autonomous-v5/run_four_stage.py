from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,torch,traceback,hashlib,sqlite3
from ygo_kito.period_runtime import PeriodBuildAssets
from ygo_kito.course_models import CourseModels
from ygo_kito.build_contracts import digest
R=Path('.cache/base-training-20261027/2207-autonomous-v5');OLD=Path('.cache/base-training-20261027/2207-autonomous-v4')
def save(n,v):(R/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n')
models=None
try:
 torch.set_num_threads(2);print('ACTUAL_FOUR_STAGE_START',datetime.now(timezone.utc).isoformat(),flush=True)
 h=json.loads((OLD/'runtime-host.json').read_text());env=json.loads(Path(h['active_environment']['path']).read_text());assets=PeriodBuildAssets(Path('.cache').resolve(),'2022-07',env,Path.cwd(),adapter_revision=5,evidence_source='user_supplied')
 binding=json.loads((R/'binding.json').read_text());models=CourseModels.from_state(torch.load(R/'latest.weights',weights_only=False),assets=assets,expected_binding=binding);before=models.versions()
 proposals=models.kernel.propose_tasks();selection=models.kernel.select_task(proposals,rank=0);save('cycle-proposals.json',proposals);save('cycle-selection.json',selection)
 receipt=json.loads((OLD/'duel-001/result.json').read_text());feedback=[{'source':'duel','message':'Actual own-candidate foundation game pearl-base-duel-001: learner first, lost to CyberDragon; native terminal true; no causal attribution to individual cards; competitive comparison labels absent. Evidence trajectory '+receipt['receipt']['trajectory_sha256']}]
 result=models.kernel.run_selected(selection,base=None,feedback=feedback);save('actual-four-stage-cycle.json',result)
 torch.save(models.save_state(),R/'latest-after-four-stage.weights')
 summary={'time_utc':datetime.now(timezone.utc).isoformat(),'actual_roles':[p['role'] for p in result['phases']],'alternation_completed':result.get('alternation_completed'),'competitive_improvement_verified':result.get('competitive_improvement_verified'),'role_parameters_changed_by_cycle':{r:before[r]!=models.versions()[r] for r in before},'cursors':models.save_state()['cursors'],'feedback_source':'actual foundation loss; no card-quality attribution','base_training_restored_without_reset':True,'optimizer_training':'pending actual fixed-driver attributable comparisons','cb_verified':result.get('cb_verified'),'effect_blocks_and_fusion_cb':'not yet complete'}
 save('four-stage-summary.json',summary)
 db=sqlite3.connect('.cache/engine-src/database/locales/zh-CN/cards.cdb');lines=['# 实际四段构筑记录','','本轮仅执行构筑推理，未发生参数更新；保留incumbent，尚无竞技改善证据。']
 def names(cards):
  return '，'.join((db.execute('select name from texts where id=?',(c,)).fetchone() or [str(c)])[0]+'×'+str(n) for c,n in Counter(cards).items())
 for p in result['phases']:
  lines+=['',str(p['phase_number'])+' '+p['role'],'输入反馈数：'+str(len(p['feedback_before'])),'决策：'+p.get('acceptance',p.get('status','unresolved'))]
  for title,k in [('输入','input_deck'),('候选输出','proposal_deck'),('保留输出','accepted_deck')]:
   if p.get(k):
    for z in ['main','extra','side']:lines.append(title+' '+z+'：'+names(p[k][z]))
  lines.append('候选相对输入变化：'+str(p.get('proposal_changes')))
 Path('docs/reports/2026-10-27-actual-four-stage-construction.zh-CN.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps(summary,ensure_ascii=False),flush=True)
except Exception as e:
 save('four-stage-error.json',{'time_utc':datetime.now(timezone.utc).isoformat(),'error':repr(e)});traceback.print_exc();raise
