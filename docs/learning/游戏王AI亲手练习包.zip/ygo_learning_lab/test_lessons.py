import importlib
import json
import os
from pathlib import Path
import tempfile
import unittest
m = importlib.import_module(os.environ.get("YGO_IMPL", "student"))
ROOT = Path(__file__).resolve().parent
CARDS = json.loads((ROOT / "data/cards.json").read_text(encoding="utf-8"))
BANS = json.loads((ROOT / "data/banlists.json").read_text(encoding="utf-8"))
class Lesson1(unittest.TestCase):
    def test_load(self): self.assertEqual(len(m.load_cards(ROOT / "data/cards.json")), 6)
    def test_chinese(self): self.assertEqual(m.load_cards(ROOT / "data/cards.json")[0]["names"]["zh"], "练习信使")
    def test_reject_object(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"bad.json"; p.write_text("{}",encoding="utf-8")
            with self.assertRaises(ValueError): m.load_cards(p)
class Lesson2(unittest.TestCase):
    def test_zh(self): self.assertEqual(m.find_card(CARDS,"练习信使")["id"],"TRAIN-001")
    def test_ja(self): self.assertEqual(m.find_card(CARDS,"練習の使者")["id"],"TRAIN-001")
    def test_en(self): self.assertEqual(m.find_card(CARDS," practice MESSENGER ")["id"],"TRAIN-001")
    def test_alias(self): self.assertEqual(m.find_card(CARDS,"样例1")["id"],"TRAIN-001")
    def test_missing(self): self.assertIsNone(m.find_card(CARDS,"不存在"))
    def test_ambiguous(self):
        extra=dict(CARDS[1]); extra["aliases"]=["样例1"]
        with self.assertRaises(ValueError): m.find_card(CARDS+[extra],"样例1")
    def test_limits(self):
        self.assertEqual([m.copy_limit(x,"25.10",BANS) for x in ["TRAIN-001","TRAIN-005","TRAIN-006"]],[1,0,3])
    def test_bad_edition(self):
        for e in ["25.13","25.1","2025-10-01","26.01"]:
            with self.subTest(edition=e):
                with self.assertRaises(ValueError): m.copy_limit("TRAIN-001",e,BANS)
class Lesson3(unittest.TestCase):
    def test_and(self): self.assertEqual([c["id"] for c in m.filter_tags(CARDS,["回收","资源"])],["TRAIN-004"])
    def test_empty(self): self.assertEqual(len(m.filter_tags(CARDS,[])),6)
    def test_no_match(self): self.assertEqual(m.filter_tags(CARDS,["不存在"]),[])
    def test_condition(self):
        self.assertFalse(m.condition_ready(CARDS[1],{}))
        self.assertFalse(m.condition_ready(CARDS[1],{"手中有伙伴":False}))
        self.assertTrue(m.condition_ready(CARDS[1],{"手中有伙伴":True}))
        self.assertTrue(m.condition_ready(CARDS[0],{}))
if __name__ == "__main__": unittest.main()
