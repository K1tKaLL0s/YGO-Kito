游戏王 AI 亲手实作练习
全部样例为虚构，不是真实卡效、官方卡号、官方禁限表。只用 Python 标准库，不需要安装包。
建议解压至 E:\YGO_Learning。先确认电脑已安装 Python：py --version。
在 PowerShell 中：
Set-Location E:\YGO_Learning\ygo_learning_lab
$env:TMP = "$PWD\temp"
$env:TEMP = "$PWD\temp"
New-Item -ItemType Directory -Force temp | Out-Null
py -B -m unittest test_lessons.Lesson1 -v
先改 student.py 的 load_cards，再依次完成 Lesson2 和 Lesson3。
全部测试：py -B -m unittest test_lessons -v
初始 TODO 会报 NotImplementedError，这是练习尚未完成的正常结果。
只在完成后核对参考答案：
$env:YGO_IMPL = "reference.solution"
py -B -m unittest test_lessons -v
Remove-Item Env:YGO_IMPL
最后一步必须执行，否则后续测试仍然在测参考答案。参考答案不要覆盖自己的 student.py。
这里设置当前进程临时目录并用 -B 禁止字节码缓存；不承诺 Python 安装、系统或编辑器完全不写入 C 盘。
参考答案已在生成环境实际通过 15 项 unittest。TODO 版本预期未通过。
