import json
import re

def load_cards(path):
    with open(path, encoding="utf-8") as f:
        cards = json.load(f)
    if not isinstance(cards, list):
        raise ValueError("卡库顶层必须为列表")
    return cards

def find_card(cards, query):
    key = query.strip().casefold()
    matches = []
    for card in cards:
        names = [card["id"], *card["names"].values(), *card.get("aliases", [])]
        if any(name.strip().casefold() == key for name in names):
            matches.append(card)
    if len({card["id"] for card in matches}) > 1:
        raise ValueError("名称有歧义")
    return matches[0] if matches else None

def copy_limit(card_id, edition, banlists):
    if not re.fullmatch(r"[0-9]{2}\.(0[1-9]|1[0-2])", edition):
        raise ValueError("版号格式应为 YY.MM")
    if edition not in banlists:
        raise ValueError("未知禁表版本")
    return banlists[edition].get(card_id, 3)

def filter_tags(cards, required):
    wanted = set(required)
    return [card for card in cards if wanted.issubset(set(card["tags"]))]

def condition_ready(card, state):
    condition = card.get("condition")
    return condition is None or state.get(condition) is True
