"""教学函数。逐课替换 TODO；样例均为虚构。"""
import json
import re
from pathlib import Path

def load_cards(path):
    # TODO 1: UTF-8 读取 JSON；只接受列表
    raise NotImplementedError("第1课：读取卡库")

def find_card(cards, query):
    # TODO 2: 匹配 ID、三语名称及别名；忽略首尾空白与英文大小写
    # 未找到返回 None；多个不同卡片匹配时抛出 ValueError
    raise NotImplementedError("第2课：名称统一")

def copy_limit(card_id, edition, banlists):
    # TODO 2: 版号必须为 YY.MM；月份 01..12；未知版本抛出 ValueError
    # 教学默认未列出为 3；这不是卡组总合法性检查
    raise NotImplementedError("第2课：版号与数量")

def filter_tags(cards, required):
    # TODO 3: 同时满足全部所需标签；空条件返回所有卡片
    raise NotImplementedError("第3课：标签筛选")

def condition_ready(card, state):
    # TODO 3: None 表示无需条件；只有对应条件显式为 True 才满足
    raise NotImplementedError("第3课：条件判断")
